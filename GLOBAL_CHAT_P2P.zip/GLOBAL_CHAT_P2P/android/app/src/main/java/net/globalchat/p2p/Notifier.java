package net.globalchat.p2p;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/** Called from the Python engine (through Chaquopy) when a message arrives. */
public class Notifier {
    static final String CHANNEL = "messages";
    private final Context ctx;

    public Notifier(Context c) {
        ctx = c.getApplicationContext();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "Messages", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("New private and group messages");
            ch.setLockscreenVisibility(Notification.VISIBILITY_PRIVATE);
            ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    /** private=true for a private chat, false for the global group. */
    public void onMessage(String peer, String name, String text, boolean priv) {
        try {
            if (MainActivity.visible) return;                       // the person is looking at the app
            if (Build.VERSION.SDK_INT >= 33
                    && ctx.checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) return;
            Intent i = new Intent(ctx, MainActivity.class)
                    .putExtra("route", priv ? "chat/" + peer : "group")
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            int id = (priv ? peer : "group").hashCode();
            PendingIntent pi = PendingIntent.getActivity(ctx, id, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification.Builder pub = build().setContentTitle("Global Chat").setContentText("New message");
            Notification.Builder b = build()
                    .setContentTitle(priv ? name : "Global group: " + name)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text))
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .setVisibility(Notification.VISIBILITY_PRIVATE)    // hide the text on the lock screen
                    .setPublicVersion(pub.build());
            ((NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id, b.build());
        } catch (Throwable ignored) { /* a failed notification must never break message delivery */ }
    }

    private Notification.Builder build() {
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx, CHANNEL) : new Notification.Builder(ctx);
        return b.setSmallIcon(android.R.drawable.stat_notify_chat);
    }
}
