# Running a bootstrap / relay peer

Two phones on different networks (for example two mobile-data users) can both be unreachable from outside. A peer
with a public address introduces them to each other and relays their already-encrypted traffic. It is an **ordinary
peer, not a server**: it cannot read, alter or forge messages, and phones keep working with any other peer you add.

## On a PC, Kali, VPS or Termux
    pip install cryptography
    bash scripts/run_node.sh                  # or: python -m gcp2p --data ~/.gcp2p-node --port 4001 --username bootstrap

It prints `gcp2p://<peerid>@PUBLIC_IP:4001`. Replace `PUBLIC_IP` with the machine's public IPv4 address.

1. **VPS** (simplest): open TCP port 4001 in the provider firewall and `ufw allow 4001/tcp`.
2. **Home PC**: forward TCP 4001 on the router to the PC and allow it in the firewall. Many carriers and some ISPs use
   CGNAT, which makes port forwarding impossible; use a VPS then.
3. Keep it running: `nohup bash scripts/run_node.sh &`, a systemd service, or `tmux`.

## On each phone
More → Network status → paste the address → **Save & connect**. It is remembered and re-used on every start. Add more
than one peer for resilience. Check Network status: *Reachability*, *Connections*, and "Relays I use" should become 1
on a phone behind NAT.

## Testing it
Phone A on Wi-Fi A, phone B on mobile data. Both add the same peer address. After a minute each should list the other
in *Online users* (if not, tap *Refresh discovery*). Messages between them travel through the relay (Network status
shows "1 relayed").

## Operator dashboard (browser)
`scripts/run_node.sh` also starts a dashboard. Open **http://127.0.0.1:4577** in a browser on the machine running the node.

* First start prints `DASHBOARD PASSWORD (shown once)`; the username is `admin`. The password is stored only as a scrypt hash
  in `<data dir>/admin.json`. To set your own: `GCP2P_ADMIN_PASSWORD='your-long-password' bash scripts/run_node.sh` (this also resets it).
* **Users online now** (big number), users known, unreachable, connections (direct / relayed) and phones using the node as relay.
* **Map of users**: a dot with the username for every user who chose to share an approximate location. Dot colour = status.
  The map needs the Leaflet library: the node downloads it once on first start (needs Internet on that machine), otherwise the
  page tries the jsDelivr CDN, otherwise it draws a simple latitude/longitude plot. Map tiles come from OpenStreetMap.
* **Table of all known users** with status, connection type, last seen and location (or "not shared").
* Change the ports: `GCP2P_PORT=4001 GCP2P_ADMIN_PORT=4577`. Turn the dashboard off by running `python -m gcp2p` without `--admin-port`.
* Reaching it from another computer: it listens on `127.0.0.1` only. Use an SSH tunnel (`ssh -L 4577:127.0.0.1:4577 user@server`)
  or `--admin-host 0.0.0.0` behind an HTTPS reverse proxy (Caddy/nginx). Never expose the plain-http port to the Internet.
* Sign-in lock: 5 wrong passwords lock that address for 15 minutes. The dashboard is read-only.

### How the map gets locations (privacy)
The node does **not** look up IP addresses. Locations are **opt-in**: on the phone, More -> Settings -> "Show me on the map",
choose a nearby city (or type latitude/longitude), tap *Share this place*. The position is rounded to 0.1 degree (about 11 km),
signed inside the user's presence record and spread to other peers; every node rejects records with more precise coordinates.
Users who do not opt in appear in the table but not on the map. Users can stop sharing at any time; their dot disappears after
the next presence update (about 3 minutes).

**Counts are not a global census**: the node only knows peers whose presence reached it. More nodes with more connections see more.
