"""Entry point called from Kotlin (Chaquopy).  Runs the engine + local API in a
background thread and returns "port:token" so Flutter can talk to it."""
import asyncio
import logging
import secrets
import threading

from gcp2p.api.server import ApiServer
from gcp2p.engine import Engine

_S = {"thread": None, "loop": None, "engine": None, "api": None, "endpoint": None}
log = logging.getLogger("gcp2p")


def start(data_dir, storage_key_hex, notifier=None, timeout=60):
    if _S["endpoint"] and _S["thread"] and _S["thread"].is_alive():
        return _S["endpoint"]
    ready, result = threading.Event(), {}

    def run():
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        _S["loop"] = loop

        async def boot():
            key = bytes.fromhex(storage_key_hex) if storage_key_hex else None
            eng = Engine(str(data_dir), key)
            if notifier is not None:
                def cb(peer, name, text, private):
                    try:
                        notifier.onMessage(str(peer), str(name), str(text), bool(private))
                    except Exception:
                        log.exception("notifier failed")
                eng.notify_cb = cb
            await eng.start()
            token = secrets.token_hex(16)
            api = ApiServer(eng, token)
            port = await api.start()
            _S.update(engine=eng, api=api)
            result["endpoint"] = f"{port}:{token}"

        try:
            loop.run_until_complete(boot())
        except Exception as exc:  # report to Kotlin instead of dying silently
            result["error"] = f"{type(exc).__name__}: {exc}"
            ready.set()
            return
        ready.set()
        loop.run_forever()

    t = threading.Thread(target=run, name="gcp2p", daemon=True)
    _S["thread"] = t
    t.start()
    if not ready.wait(timeout):
        raise RuntimeError("engine start timed out")
    if "error" in result:
        raise RuntimeError(result["error"])
    _S["endpoint"] = result["endpoint"]
    return _S["endpoint"]


def kick():
    """Call when the network changes so peers are re-dialed immediately."""
    eng, loop = _S.get("engine"), _S.get("loop")
    if eng and eng.node and loop:
        loop.call_soon_threadsafe(eng.node.kick)


def stop():
    eng, loop = _S.get("engine"), _S.get("loop")
    if eng and loop:
        fut = asyncio.run_coroutine_threadsafe(eng.stop(), loop)
        try:
            fut.result(10)
        except Exception:
            pass
        loop.call_soon_threadsafe(loop.stop)
    _S.update(endpoint=None, engine=None, api=None)
