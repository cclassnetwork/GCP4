"""Transport links and the authenticated, encrypted channel.

RawLink      - moves opaque byte messages (TCP, or a relay circuit).
SecureChannel- mutual-authenticated AEAD channel built on any RawLink.

Handshake (both sides prove ownership of their Ed25519 identity):
  1. I -> R : "GCP1" | eph_pub_I | nonce_I
  2. R -> I : "GCP1" | eph_pub_R | nonce_R
     transcript = SHA256("gcp2p-hs" | msg1 | msg2)
     keys = HKDF(ECDH(eph), salt=transcript) -> k_i2r | k_r2i
  3. I -> R : AEAD{ pub_I, Sign_I("gcp2p-auth-i" | transcript) }
  4. R -> I : AEAD{ pub_R, Sign_R("gcp2p-auth-r" | transcript) }
Fresh ephemeral keys give forward secrecy for the transport; identities are
sent only inside the encrypted channel.
"""
from __future__ import annotations

import asyncio
import json
import os
import struct

from cryptography.hazmat.primitives.asymmetric.x25519 import X25519PrivateKey
from cryptography.hazmat.primitives.ciphers.aead import ChaCha20Poly1305

from ..encryption import crypto

MAGIC = b"GCP1"
MAX_RAW = 1 << 20          # 1 MiB per transport message
MAX_PLAIN = 512 * 1024     # largest application message


class LinkClosed(Exception):
    pass


class ChannelError(Exception):
    pass


class RawLink:
    ip: str = ""
    port: int = 0

    async def read(self) -> bytes:  # pragma: no cover - interface
        raise NotImplementedError

    async def write(self, data: bytes) -> None:  # pragma: no cover
        raise NotImplementedError

    def close(self) -> None:  # pragma: no cover
        pass


class TcpLink(RawLink):
    def __init__(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter):
        self.r = reader
        self.w = writer
        pn = writer.get_extra_info("peername")
        self.ip = pn[0] if pn else ""
        self.port = pn[1] if pn else 0

    async def read(self) -> bytes:
        try:
            hdr = await self.r.readexactly(4)
            n = struct.unpack(">I", hdr)[0]
            if n > MAX_RAW:
                raise LinkClosed("frame too large")
            return await self.r.readexactly(n)
        except (asyncio.IncompleteReadError, ConnectionError, OSError) as exc:
            raise LinkClosed(str(exc)) from exc

    async def write(self, data: bytes) -> None:
        if len(data) > MAX_RAW:
            raise LinkClosed("message too large")
        try:
            self.w.write(struct.pack(">I", len(data)) + data)
            await self.w.drain()
        except (ConnectionError, OSError) as exc:
            raise LinkClosed(str(exc)) from exc

    def close(self) -> None:
        try:
            self.w.close()
        except Exception:
            pass


class QueueLink(RawLink):
    """A link whose inbound messages are pushed into a queue (relay circuits)."""

    def __init__(self, sender):
        self._q: asyncio.Queue = asyncio.Queue(maxsize=256)
        self._send = sender
        self.closed = False

    def feed(self, data: bytes | None) -> None:
        try:
            self._q.put_nowait(data)
        except asyncio.QueueFull:
            self.close()

    async def read(self) -> bytes:
        if self.closed and self._q.empty():
            raise LinkClosed("closed")
        item = await self._q.get()
        if item is None:
            raise LinkClosed("closed")
        return item

    async def write(self, data: bytes) -> None:
        if self.closed:
            raise LinkClosed("closed")
        await self._send(data)

    def close(self) -> None:
        if not self.closed:
            self.closed = True
            try:
                self._q.put_nowait(None)
            except asyncio.QueueFull:
                pass


def _nonce(counter: int) -> bytes:
    return b"\x00\x00\x00\x00" + struct.pack(">Q", counter)


class SecureChannel:
    def __init__(self, link: RawLink, send_key: bytes, recv_key: bytes, remote_pub: bytes):
        self.link = link
        self._send = ChaCha20Poly1305(send_key)
        self._recv = ChaCha20Poly1305(recv_key)
        self._sn = 1  # counter 0 was used by the auth frame
        self._rn = 1
        self._lock = asyncio.Lock()
        self.remote_pub = remote_pub
        self.remote_id = crypto.peer_id_from_pub(remote_pub)

    async def send(self, obj: dict) -> None:
        data = json.dumps(obj, separators=(",", ":")).encode("utf-8")
        if len(data) > MAX_PLAIN:
            raise ChannelError("message too large")
        async with self._lock:
            ct = self._send.encrypt(_nonce(self._sn), data, b"")
            self._sn += 1
            await self.link.write(ct)

    async def recv(self) -> dict:
        ct = await self.link.read()
        try:
            data = self._recv.decrypt(_nonce(self._rn), ct, b"")
        except Exception as exc:
            raise ChannelError("decryption failed") from exc
        self._rn += 1
        try:
            obj = json.loads(data.decode("utf-8"))
        except Exception as exc:
            raise ChannelError("bad json") from exc
        if not isinstance(obj, dict):
            raise ChannelError("bad message")
        return obj

    def close(self) -> None:
        self.link.close()


async def handshake(link: RawLink, identity, initiator: bool, expect_peer: str | None = None,
                    timeout: float = 10.0) -> SecureChannel:
    try:
        return await asyncio.wait_for(_handshake(link, identity, initiator, expect_peer), timeout)
    except asyncio.TimeoutError as exc:
        link.close()
        raise ChannelError("handshake timeout") from exc
    except (LinkClosed, crypto.CryptoError) as exc:
        link.close()
        raise ChannelError(f"handshake failed: {exc}") from exc


async def _handshake(link, identity, initiator, expect_peer):
    esk = X25519PrivateKey.generate()
    epk = crypto.x25519_pub_bytes(esk)
    mine = MAGIC + epk + os.urandom(16)
    if initiator:
        await link.write(mine)
        theirs = await link.read()
        msg1, msg2 = mine, theirs
    else:
        theirs = await link.read()
        await link.write(mine)
        msg1, msg2 = theirs, mine
    if len(theirs) != 4 + 32 + 16 or theirs[:4] != MAGIC:
        raise crypto.CryptoError("bad hello")
    shared = crypto.ecdh(esk, theirs[4:36])
    transcript = crypto.sha256(b"gcp2p-hs" + msg1 + msg2)
    keys = crypto.hkdf(shared, salt=transcript, info=b"gcp2p-keys", length=64)
    k_i2r, k_r2i = keys[:32], keys[32:]
    send_key, recv_key = (k_i2r, k_r2i) if initiator else (k_r2i, k_i2r)
    sender, receiver = ChaCha20Poly1305(send_key), ChaCha20Poly1305(recv_key)
    my_label = b"gcp2p-auth-i" if initiator else b"gcp2p-auth-r"
    their_label = b"gcp2p-auth-r" if initiator else b"gcp2p-auth-i"

    async def send_auth():
        body = json.dumps({
            "pub": crypto.b64e(identity.pub),
            "sig": crypto.b64e(identity.sign(my_label + transcript)),
        }).encode()
        await link.write(sender.encrypt(_nonce(0), body, b""))

    async def read_auth():
        raw = await link.read()
        try:
            body = json.loads(receiver.decrypt(_nonce(0), raw, b"").decode())
            pub = crypto.b64d(body["pub"])
            sig = crypto.b64d(body["sig"])
        except Exception as exc:
            raise crypto.CryptoError("bad auth frame") from exc
        if len(pub) != 32 or not crypto.verify(pub, sig, their_label + transcript):
            raise crypto.CryptoError("peer failed to prove its identity")
        return pub

    if initiator:
        await send_auth()
        pub = await read_auth()
    else:
        pub = await read_auth()
        await send_auth()
    remote_id = crypto.peer_id_from_pub(pub)
    if remote_id == identity.peer_id:
        raise crypto.CryptoError("connected to myself")
    if expect_peer and remote_id != expect_peer:
        raise crypto.CryptoError("peer identity mismatch")
    return SecureChannel(link, send_key, recv_key, pub)
