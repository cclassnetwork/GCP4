"""Signed, expiring presence records and the online-users directory.

A presence record says "peer X (public key P, username U) was reachable at
addresses A at time T and this claim is valid for TTL seconds".  It is
signed by X, so nobody can forge a username/identity or keep someone
"online" after the TTL.  Records spread by gossip and are stored in the DHT.

LIMITS (see docs/NETWORKING.md): a decentralized network has no global user
list.  You only see peers whose records reached you; very large networks
would only show a sample.  "online" is verified by actually reaching the peer.
"""
from __future__ import annotations

import asyncio
import re
import time

from ..encryption import crypto
from ..identity.identity import USERNAME_RE, handle
from ..networking.ratelimit import KeyedLimiter

PRESENCE_TTL = 180
MAX_ADDRS = 8
MAX_ENTRIES = 1000
PROBE_FRESH = 120
_ADDR_RE = re.compile(r"^[A-Za-z0-9:./_\-\[\]]{3,160}$")


class RecordError(Exception):
    pass


def coarse(v: float) -> float:
    """Locations are rounded to 0.1 degree (about 11 km) before they are signed."""
    return round(float(v), 1)


def valid_loc(loc) -> bool:
    """[lat, lon], in range, already rounded to 0.1 degree: nodes reject anything more precise."""
    return (isinstance(loc, list) and len(loc) == 2
            and all(isinstance(v, (int, float)) and not isinstance(v, bool) and v == v for v in loc)
            and -90 <= loc[0] <= 90 and -180 <= loc[1] <= 180 and all(round(v, 1) == v for v in loc))


def make_record(identity, username: str, addrs: list, ttl: int = PRESENCE_TTL, ts: float | None = None,
                loc: list | None = None) -> dict:
    rec = {
        "peer": identity.peer_id,
        "pub": crypto.b64e(identity.pub),
        "xpk": crypto.b64e(identity.xpub),
        "username": username,
        "addrs": list(addrs)[:MAX_ADDRS],
        "ts": round(ts if ts is not None else time.time(), 3),
        "ttl": int(ttl),
    }
    if loc is not None:      # optional, only when the user chose to appear on the map
        rec["loc"] = [coarse(loc[0]), coarse(loc[1])]
    rec["sig"] = crypto.b64e(identity.sign(b"gcp2p-presence|" + crypto.canonical(rec)))
    return rec


def verify_record(rec, now: float) -> dict:
    """Return the record if valid, else raise RecordError."""
    if not isinstance(rec, dict):
        raise RecordError("not an object")
    try:
        peer, username = rec["peer"], rec["username"]
        ts, ttl, addrs = rec["ts"], rec["ttl"], rec["addrs"]
        pub, xpk, sig = crypto.b64d(rec["pub"]), crypto.b64d(rec["xpk"]), crypto.b64d(rec["sig"])
    except (KeyError, crypto.CryptoError) as exc:
        raise RecordError("malformed") from exc
    base = {"peer", "pub", "xpk", "username", "addrs", "ts", "ttl", "sig"}
    if set(rec) != base and set(rec) != base | {"loc"}:
        raise RecordError("unexpected fields")
    if "loc" in rec and not valid_loc(rec["loc"]):
        raise RecordError("bad location")
    if not isinstance(ts, (int, float)) or isinstance(ts, bool) or not isinstance(ttl, int) or isinstance(ttl, bool):
        raise RecordError("bad numbers")
    if not (0 <= ttl <= 3600):
        raise RecordError("bad ttl")
    if len(pub) != 32 or len(xpk) != 32:
        raise RecordError("bad key size")
    if peer != crypto.peer_id_from_pub(pub):
        raise RecordError("peer id does not match key")
    if not isinstance(username, str) or not USERNAME_RE.match(username):
        raise RecordError("bad username")
    if not isinstance(addrs, list) or len(addrs) > MAX_ADDRS or not all(
            isinstance(a, str) and _ADDR_RE.match(a) for a in addrs):
        raise RecordError("bad addresses")
    if ts > now + 120:
        raise RecordError("timestamp in the future")
    if now - ts > max(ttl, 300) + 60:
        raise RecordError("expired")
    body = {k: v for k, v in rec.items() if k != "sig"}
    if not crypto.verify(pub, sig, b"gcp2p-presence|" + crypto.canonical(body)):
        raise RecordError("bad signature")
    return rec


class Entry:
    __slots__ = ("rec", "rx", "probe_ok", "probe_ts")

    def __init__(self, rec, rx):
        self.rec, self.rx = rec, rx
        self.probe_ok: bool | None = None
        self.probe_ts = 0.0


class PresenceService:
    def __init__(self, node):
        self.node = node
        self.entries: dict[str, Entry] = {}
        self.limiter = KeyedLimiter(rate=0.2, burst=3, clock=node.now)
        node.handlers["pres_req"] = self.on_pres_req

    # ---- publishing ---------------------------------------------------------
    def own_record(self, ttl: int = PRESENCE_TTL) -> dict:
        return make_record(self.node.identity, self.node.username, self.node.advertised_addrs(), ttl, self.node.now(),
                           loc=self.node.location)

    async def publish(self, ttl: int = PRESENCE_TTL) -> None:
        rec = self.own_record(ttl)
        await self.node.broadcast({"t": "g", "k": "pres", "m": rec, "h": 0}, fanout=50)
        try:
            await self.node.dht.store_record(rec)
        except Exception:
            pass

    # ---- receiving ----------------------------------------------------------
    def ingest(self, rec) -> bool:
        """Validate and store a record.  True if it is new information."""
        now = self.node.now()
        rec = verify_record(rec, now)
        if rec["peer"] == self.node.id:
            return False
        cur = self.entries.get(rec["peer"])
        if cur and rec["ts"] <= cur.rec["ts"]:
            return False
        if rec["ttl"] > 0 and not self.limiter.allow(rec["peer"]):
            return False
        e = Entry(rec, now)
        if cur:
            e.probe_ok, e.probe_ts = cur.probe_ok, cur.probe_ts
            if rec["ttl"] == 0:
                e.probe_ok, e.probe_ts = False, now
        self.entries[rec["peer"]] = e
        if len(self.entries) > MAX_ENTRIES:
            oldest = min(self.entries, key=lambda p: self.entries[p].rx)
            self.entries.pop(oldest, None)
        self.node.db.upsert_peer(rec["peer"], pub=crypto.b64d(rec["pub"]), xpk=crypto.b64d(rec["xpk"]),
                                 username=rec["username"], addrs=rec["addrs"] or None, seen=rec["ts"])
        self.node.emit("presence", {"peer": rec["peer"]})
        return True

    async def on_gossip(self, conn, m, hops: int) -> bool:
        try:
            new = self.ingest(m)
        except RecordError:
            self.node.penalize(conn, 20, "invalid presence record")
            return False
        return new

    async def on_pres_req(self, conn, msg) -> dict:
        now = self.node.now()
        recs = [e.rec for e in self.entries.values() if e.rec["ttl"] > 0 and now - e.rec["ts"] <= e.rec["ttl"]]
        recs.append(self.own_record())
        return {"recs": recs[:150]}

    async def sync_from(self, conn) -> None:
        try:
            res = await conn.request({"t": "pres_req"}, timeout=8)
        except Exception:
            return
        for rec in (res.get("recs") or [])[:150]:
            try:
                self.ingest(rec)
            except RecordError:
                self.node.penalize(conn, 10, "invalid presence record in sync")

    # ---- querying -----------------------------------------------------------
    def state_of(self, peer_id: str) -> str:
        e = self.entries.get(peer_id)
        now = self.node.now()
        if e is None:
            return "offline"
        if e.rec["ttl"] == 0 or now - e.rec["ts"] > e.rec["ttl"]:
            return "offline"
        c = self.node.conns.get(peer_id)
        if c is not None and c.ready.is_set():
            return "online"
        if e.probe_ts and now - e.probe_ts < PROBE_FRESH:
            return "online" if e.probe_ok else "unreachable"
        return "checking"

    def directory(self) -> list:
        now = self.node.now()
        out = []
        for pid, e in self.entries.items():
            r = e.rec
            c = self.node.conns.get(pid)
            via = "none"
            if c is not None and c.ready.is_set():
                via = "relay" if c.via_relay else "direct"
            out.append({
                "peer_id": pid, "username": r["username"], "handle": handle(r["username"], pid),
                "state": self.state_of(pid), "last_seen": r["ts"], "age": round(now - r["ts"], 1),
                "via": via, "addrs": r["addrs"], "loc": r.get("loc"),
            })
        order = {"online": 0, "checking": 1, "unreachable": 2, "offline": 3}
        out.sort(key=lambda d: (order[d["state"]], d["username"].lower()))
        return out

    async def probe(self, peer_id: str) -> bool:
        e = self.entries.get(peer_id)
        if e is None:
            return False
        ok = False
        try:
            conn = await self.node.get_conn(peer_id, e.rec["addrs"])
            if conn is not None:
                await conn.request({"t": "ping"}, timeout=6)
                ok = True
        except Exception:
            ok = False
        e.probe_ok, e.probe_ts = ok, self.node.now()
        self.node.emit("presence", {"peer": peer_id})
        return ok

    async def refresh(self, max_probe: int = 30) -> None:
        """Ask connected peers for their directories, then verify reachability."""
        convs = [c for c in self.node.conns.values() if c.ready.is_set()][:8]
        await asyncio.gather(*[self.sync_from(c) for c in convs], return_exceptions=True)
        now = self.node.now()
        fresh = [p for p, e in self.entries.items() if e.rec["ttl"] > 0 and now - e.rec["ts"] <= e.rec["ttl"]]
        sem = asyncio.Semaphore(6)

        async def one(p):
            async with sem:
                await self.probe(p)

        await asyncio.gather(*[one(p) for p in fresh[:max_probe]], return_exceptions=True)

    def expire(self) -> None:
        now = self.node.now()
        for pid in [p for p, e in self.entries.items() if now - e.rec["ts"] > 86400]:
            self.entries.pop(pid, None)
