import json, os, time
import pytest
from gcp2p.encryption import crypto
from gcp2p.identity.identity import Identity, IdentityError, validate_username, handle
from gcp2p.presence.presence import make_record, verify_record, RecordError
from gcp2p.group_chat.group import make_message, verify_message, GroupError


def test_identity_is_anonymous_and_unique():
    a, b = Identity.generate(), Identity.generate()
    assert a.peer_id != b.peer_id
    assert crypto.valid_peer_id(a.peer_id)
    assert a.peer_id == crypto.peer_id_from_pub(a.pub)      # derived from the public key


def test_identity_roundtrip_keeps_peer_id():
    a = Identity.generate()
    b = Identity.from_bytes(a.to_bytes())
    assert b.peer_id == a.peer_id and b.pub == a.pub and b.xpub == a.xpub
    sig = b.sign(b"x")
    assert crypto.verify(a.pub, sig, b"x")


def test_username_change_does_not_change_peer_id():
    a = Identity.generate()
    r1 = make_record(a, "sani", [])
    r2 = make_record(a, "sani_new", [], ts=time.time() + 1)
    assert r1["peer"] == r2["peer"] == a.peer_id
    assert r1["username"] != r2["username"]


@pytest.mark.parametrize("bad", ["", "ab", "a" * 25, "has space", "emoji😀", "semi;colon", None, 5])
def test_username_validation_rejects(bad):
    with pytest.raises(IdentityError):
        validate_username(bad)


def test_username_validation_accepts_and_handle_shows_id_suffix():
    assert validate_username("  Sani_01 ") == "Sani_01"
    pid = Identity.generate().peer_id
    assert handle("Sani", pid).endswith("#" + pid[-4:])


def test_key_wrapping_roundtrip_and_wrong_key():
    key, data = os.urandom(32), os.urandom(64)
    blob = crypto.wrap(key, data, b"id")
    assert crypto.unwrap(key, blob, b"id") == data
    with pytest.raises(crypto.CryptoError):
        crypto.unwrap(os.urandom(32), blob, b"id")
    with pytest.raises(crypto.CryptoError):
        crypto.unwrap(key, blob, b"other-label")
    assert data not in blob


def test_seal_unseal_and_tamper_detection():
    r = Identity.generate()
    env = crypto.seal(r.xpub, b"secret text", b"aad")
    assert b"secret text" not in json.dumps(env).encode()
    assert crypto.unseal(r.x_sk, r.xpub, env, b"aad") == b"secret text"
    with pytest.raises(crypto.CryptoError):
        crypto.unseal(r.x_sk, r.xpub, env, b"different-aad")
    other = Identity.generate()
    with pytest.raises(crypto.CryptoError):
        crypto.unseal(other.x_sk, other.xpub, env, b"aad")
    bad = dict(env); ct = bytearray(crypto.b64d(env["c"])); ct[0] ^= 1; bad["c"] = crypto.b64e(bytes(ct))
    with pytest.raises(crypto.CryptoError):
        crypto.unseal(r.x_sk, r.xpub, bad, b"aad")


def test_presence_record_valid_and_forgeries_rejected():
    a, evil = Identity.generate(), Identity.generate()
    now = time.time()
    rec = make_record(a, "sani", ["127.0.0.1:1"], ts=now)
    assert verify_record(rec, now)["peer"] == a.peer_id
    # forged username: changing a signed field breaks the signature
    forged = dict(rec, username="admin")
    with pytest.raises(RecordError):
        verify_record(forged, now)
    # claiming someone else's peer id with your own key
    steal = make_record(evil, "sani", [], ts=now); steal["peer"] = a.peer_id
    with pytest.raises(RecordError):
        verify_record(steal, now)
    # tampered addresses
    with pytest.raises(RecordError):
        verify_record(dict(rec, addrs=["6.6.6.6:9"]), now)
    # junk
    for junk in (None, {}, {"peer": 1}, dict(rec, ttl=99999), dict(rec, addrs="x")):
        with pytest.raises(RecordError):
            verify_record(junk, now)


def test_presence_expiry_and_future_timestamps():
    a = Identity.generate(); now = time.time()
    old = make_record(a, "sani", [], ttl=180, ts=now - 1000)
    with pytest.raises(RecordError):
        verify_record(old, now)
    fut = make_record(a, "sani", [], ts=now + 3600)
    with pytest.raises(RecordError):
        verify_record(fut, now)


def test_group_message_signature_and_replay_window():
    a = Identity.generate(); now = time.time()
    m = make_message(a, "sani", "hello", now)
    assert verify_message(m, now)["body"] == "hello"
    with pytest.raises(GroupError):
        verify_message(dict(m, body="tampered"), now)
    with pytest.raises(GroupError):
        verify_message(dict(m, username="musa"), now)
    old = make_message(a, "sani", "old", now - 3600)
    with pytest.raises(GroupError):                       # replayed old message is outside the live window
        verify_message(old, now)
    assert verify_message(old, now, window=86400)         # ...but is accepted by explicit history sync
    with pytest.raises(GroupError):
        verify_message(make_message(a, "sani", "x" * 1001, now), now)
    with pytest.raises(GroupError):
        verify_message(make_message(a, "sani", "   ", now), now)
