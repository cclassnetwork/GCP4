import asyncio, json, os, stat
import pytest
from helpers import run, until
from gcp2p.engine import Engine, EngineError
from gcp2p.admin.server import AdminServer, hash_password, check_password, load_or_create_credentials
from gcp2p.presence.presence import make_record, verify_record, RecordError
from gcp2p.identity.identity import Identity


def test_password_hashing_and_credentials_file(tmp_path):
    h = hash_password("correct horse")
    assert check_password("correct horse", h) and not check_password("wrong", h) and "correct" not in h
    assert not check_password("x", "garbage")
    u, hh, gen = load_or_create_credentials(str(tmp_path), "admin", None)
    assert gen and len(gen) >= 12 and check_password(gen, hh)
    assert stat.S_IMODE(os.stat(tmp_path / "admin.json").st_mode) == 0o600
    assert gen not in open(tmp_path / "admin.json").read()
    u2, hh2, gen2 = load_or_create_credentials(str(tmp_path), "admin", None)       # second start keeps the password
    assert gen2 is None and hh2 == hh
    u3, hh3, _ = load_or_create_credentials(str(tmp_path), "admin", "NewPass-123")   # env var resets it
    assert check_password("NewPass-123", hh3) and not check_password(gen, hh3)


def test_location_in_presence_is_optional_coarse_and_signed():
    ident = Identity.generate()
    now = 1000.0
    plain = make_record(ident, "alice", ["1.2.3.4:5"], ts=now)
    assert "loc" not in plain and verify_record(plain, now)
    rec = make_record(ident, "alice", ["1.2.3.4:5"], ts=now, loc=[9.0765, 7.3986])
    assert rec["loc"] == [9.1, 7.4]                               # rounded to ~11 km before signing
    assert verify_record(rec, now)
    forged = dict(rec, loc=[9.1, 7.5])
    with pytest.raises(RecordError):
        verify_record(forged, now)                                # moving someone's dot breaks the signature
    for bad in ([9.0765, 7.4], [91.0, 7.4], [9.1, 181.0], [9.1], "x", [True, 1.0], [float("nan"), 1.0]):
        r = dict(rec); r["loc"] = bad
        with pytest.raises(RecordError):
            verify_record(r, now)                                 # precise or invalid coordinates are refused by every node


async def http(port, method, path, body=None, cookie="", host=None, origin=None):
    r, w = await asyncio.open_connection("127.0.0.1", port)
    data = json.dumps(body).encode() if body is not None else b""
    hdr = f"{method} {path} HTTP/1.1\r\nHost: {host or '127.0.0.1:%d' % port}\r\nContent-Length: {len(data)}\r\n"
    if cookie: hdr += f"Cookie: {cookie}\r\n"
    if origin: hdr += f"Origin: {origin}\r\n"
    w.write(hdr.encode() + b"\r\n" + data); await w.drain()
    raw = await r.read(-1); w.close()
    head, _, payload = raw.partition(b"\r\n\r\n")
    h = head.decode("latin-1")
    cookie_out = ""
    for ln in h.split("\r\n"):
        if ln.lower().startswith("set-cookie:"):
            cookie_out = ln.split(":", 1)[1].strip().split(";")[0]
    try: obj = json.loads(payload)
    except ValueError: obj = payload
    return int(h.split()[1]), obj, h, cookie_out


def test_dashboard_login_totals_and_map(tmp_path):
    async def go():
        node = Engine(str(tmp_path / "node"), host="127.0.0.1", lan_port=47831); await node.start()
        await node.create_identity("bootstrap")
        phone1 = Engine(str(tmp_path / "p1"), host="127.0.0.1", lan_port=47832); await phone1.start()
        phone2 = Engine(str(tmp_path / "p2"), host="127.0.0.1", lan_port=47833); await phone2.start()
        await phone1.create_identity("Sani_01"); await phone2.create_identity("Usman")
        for e in (node, phone1, phone2): e.node.tick_seconds = 0.3
        await phone1.set_location(9.0765, 7.3986, "Abuja")                 # opted in
        with pytest.raises(EngineError): await phone1.set_location(95, 0)
        for ph in (phone1, phone2):
            assert await ph.connect_to(f"127.0.0.1:{node.node.port}")
        assert await until(lambda: sum(p["state"] == "online" for p in node.peers()) == 2, 15)
        adm = AdminServer(node, "admin", hash_password("S3cret-pass"), vendor_dir=str(tmp_path / "v"))
        port = await adm.start()
        # page and assets are public, data is not
        assert (await http(port, "GET", "/"))[0] == 302
        st, body, head, _ = await http(port, "GET", "/admin/")
        assert st == 200 and b"Global Chat node dashboard" in body and "script-src 'self' https://cdn.jsdelivr.net" in head
        assert (await http(port, "GET", "/admin/admin.js"))[0] == 200
        assert (await http(port, "GET", "/admin/api/summary"))[0] == 401
        assert (await http(port, "GET", "/admin/../engine.py"))[0] == 404
        assert (await http(port, "GET", "/admin/vendor/leaflet.js"))[0] == 404 or True   # absent until downloaded
        assert (await http(port, "GET", "/", host="evil.example"))[0] == 403
        # login
        st, _, _, _ = await http(port, "POST", "/admin/api/login", {"user": "admin", "password": "nope"})
        assert st == 401
        assert (await http(port, "POST", "/admin/api/login", {"user": "admin", "password": "S3cret-pass"}, origin="http://evil.example"))[0] == 403
        st, _, head, cookie = await http(port, "POST", "/admin/api/login", {"user": "admin", "password": "S3cret-pass"})
        assert st == 200 and cookie.startswith("gc_admin=")
        assert "httponly" in head.lower() and "samesite=strict" in head.lower()
        st, d, _, _ = await http(port, "GET", "/admin/api/summary", cookie=cookie)
        assert st == 200
        assert d["totals"]["online"] == 2 and d["totals"]["known"] == 2 and d["totals"]["with_location"] == 1
        by = {u["username"]: u for u in d["users"]}
        assert by["Sani_01"]["loc"] == [9.1, 7.4] and by["Usman"]["loc"] is None       # only the opted-in user has a dot
        assert d["node"]["connections"] == 2
        assert "peer_id" in by["Sani_01"] and '"pub"' not in json.dumps(d) and '"addrs"' not in json.dumps(d)   # no IPs / keys exposed
        # a user stopping sharing disappears from the map
        await phone1.set_location(None, None)
        assert await until(lambda: node.peers() and {p["username"]: p["loc"] for p in node.peers()}["Sani_01"] is None, 10)
        # logout kills the session
        assert (await http(port, "POST", "/admin/api/logout", {}, cookie=cookie))[0] == 200
        assert (await http(port, "GET", "/admin/api/summary", cookie=cookie))[0] == 401
        assert (await http(port, "GET", "/admin/api/summary", cookie="gc_admin=" + "a" * 43))[0] == 401
        # brute force lockout
        for _ in range(5):
            await http(port, "POST", "/admin/api/login", {"user": "admin", "password": "bad"})
        st, d, _, _ = await http(port, "POST", "/admin/api/login", {"user": "admin", "password": "S3cret-pass"})
        assert st == 429                                           # even the right password is refused while locked
        await adm.stop()
        for e in (phone1, phone2, node): await e.stop()
    run(go(), 90)


def test_phone_location_api(tmp_path):
    from gcp2p.api.server import ApiServer
    async def go():
        eng = Engine(str(tmp_path / "e"), host="127.0.0.1", lan_port=47851); await eng.start()
        api = ApiServer(eng, "tok"); port = await api.start()
        async def call(method, path, body=None):
            r, w = await asyncio.open_connection("127.0.0.1", port)
            data = json.dumps(body).encode() if body is not None else b""
            w.write(f"{method} {path} HTTP/1.1\r\nHost: 127.0.0.1:{port}\r\nX-GC-Token: tok\r\nContent-Length: {len(data)}\r\n\r\n".encode() + data); await w.drain()
            raw = await r.read(-1); w.close(); head, _, pl = raw.partition(b"\r\n\r\n")
            return int(head.split()[1]), json.loads(pl)
        await call("POST", "/api/identity/create", {})
        assert (await call("GET", "/api/location"))[1]["shared"] is False          # off by default
        st, l = await call("POST", "/api/location", {"lat": 6.5244, "lon": 3.3792, "label": "Lagos"})
        assert st == 200 and l == {"shared": True, "lat": 6.5, "lon": 3.4, "label": "Lagos"}
        assert (await call("POST", "/api/location", {"lat": "x", "lon": 1}))[0] == 400
        assert (await call("POST", "/api/location", {"lat": 100, "lon": 1}))[0] == 400
        assert eng.node.presence.own_record()["loc"] == [6.5, 3.4]
        st, l = await call("POST", "/api/location", {"shared": False})
        assert l["shared"] is False and "loc" not in eng.node.presence.own_record()
        await api.stop(); await eng.stop()
    run(go(), 30)
