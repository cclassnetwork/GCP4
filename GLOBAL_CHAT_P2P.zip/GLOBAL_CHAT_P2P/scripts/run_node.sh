#!/usr/bin/env bash
# Run a Global Chat peer on a PC / Kali / VPS / Termux. Needs: python3 and `pip install cryptography`.
#   bash scripts/run_node.sh            # listens on port 4001
# Open that port in your router/firewall (TCP 4001) so phones on mobile data can reach it.
set -euo pipefail
cd "$(dirname "$0")/../python"
exec python3 -m gcp2p --data "${GCP2P_DATA:-$HOME/.gcp2p-node}" --port "${GCP2P_PORT:-4001}" --admin-port "${GCP2P_ADMIN_PORT:-4577}" --username "${GCP2P_NAME:-bootstrap}" "$@"
