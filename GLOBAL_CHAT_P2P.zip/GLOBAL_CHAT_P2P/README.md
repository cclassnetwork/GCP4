# GLOBAL CHAT P2P

A decentralised messenger for Android. **Every phone running the app is a node.** There is no chat server, no
user database, no Firebase/Supabase and no account: no phone number, no email.

* anonymous identity (Ed25519 + X25519 keys made on the phone; the peer ID is derived from the public key)
* private chat: end-to-end encrypted, delivery status, local history, automatic retry, encrypted offline mailbox
* user-created groups: public (discoverable, one-tap join) or private (encrypted, invite code)
* global group chat: signed messages, gossip between peers, duplicate/replay/spam protection
* online-users list built from signed, expiring presence records (nothing hard-coded or simulated)
* Kademlia-style DHT for discovery, local Wi-Fi discovery, circuit relays for phones behind mobile NAT
* the whole program (engine + screens) runs **inside the APK**; nothing is downloaded at run time

## Honest status

| Part | State |
|---|---|
| Engine (identity, crypto, DHT, presence, DM, group, relay, offline mailbox, storage, rate limiting) | Written and **tested here** with real nodes over real sockets on one machine (44 automated tests) |
| Screens (all 12) | Written and **tested here** in headless Chromium against two live engines |
| Android shell (Chaquopy, Keystore, notifications, foreground service) | Written; **has not been run on a phone by me.** The APK is built by GitHub Actions; the first install is the first real test |
| Two phones on **different internet connections** | **Not tested.** Needs a publicly reachable peer (see `docs/BOOTSTRAP_NODE.md`). Only the logic is tested, on one machine |
| NAT hole punching | **Not implemented.** Phones behind carrier NAT use a circuit relay instead |
| Push notifications while the app is fully closed | **Not possible** without a push server; the app stays connected through a foreground service instead |
| Independent security audit | **None.** Standard primitives are used, the protocol built from them has not been reviewed |

### Why the screens are not Flutter
The brief asked for Flutter. Flutter cannot be compiled in the environment this project was written in, so Flutter
code could not have been tested before reaching you, and an untested UI would likely have failed to build on your
phone. The screens are therefore web pages (`python/gcp2p/web/`) served by the engine on `127.0.0.1` and shown in the
Android WebView, the same approach as your CCLASS APK. They follow the requested design (dark navy, black/deep-blue
surfaces, turquoise accents, rounded cards, smooth animations, Material-style bottom navigation). The engine does not
depend on the UI, so a Flutter front end could be added later against the same local API (`docs/ARCHITECTURE.md`).

## Install on your phone (no computer needed)
See `docs/BUILD_APK.md`. In short: create a **new** GitHub repository, upload `GLOBAL_CHAT_P2P.zip`, add
`.github/workflows/android.yml`, run "Global Chat APK" and download the `globalchat-apk` artifact.

## Make it work between different networks
Two phones can only find and reach each other across the Internet if at least one **publicly reachable peer** is
available to introduce them and relay. Run one on a PC, Kali or cheap VPS (it is an ordinary peer and cannot read
anything):

    pip install cryptography
    bash scripts/run_node.sh            # prints  gcp2p://<peerid>@PUBLIC_IP:4001

In each phone: More → Network status → paste that address → *Save & connect*. Details: `docs/BOOTSTRAP_NODE.md`.
Phones on the same Wi-Fi find each other automatically with no setup.

The same command starts an **operator dashboard** at `http://127.0.0.1:4577` (login, users online, map with a dot and username for every
user who opted in to share an approximate location). See `docs/BOOTSTRAP_NODE.md`.

## Run / test on a computer
    bash scripts/run_tests.sh                      # all tests
    python -m gcp2p --data ./n1 --port 4001 --username alice --api-port 0     # a node with the local API

## Layout
    python/gcp2p/identity      keys, peer ID, username rules
    python/gcp2p/encryption    Ed25519, X25519, HKDF, ChaCha20-Poly1305 wrappers
    python/gcp2p/discovery     Kademlia DHT, local Wi-Fi beacons
    python/gcp2p/networking    node/connection manager, secure channel, relay, rate limits
    python/gcp2p/presence      signed expiring presence + online-users directory
    python/gcp2p/messaging     private messages, offline mailbox, retry, receipts
    python/gcp2p/group_chat    global group gossip + sync
    python/gcp2p/storage       SQLite
    python/gcp2p/api           local HTTP/SSE API (the bridge) and static file server
    python/gcp2p/web           the 12 screens (HTML/CSS/JS)
    python/gc_android.py       entry point called from Java through Chaquopy
    android/                   Chaquopy project (Java): Activity, Keystore vault, notifications, foreground service
    python/tests, docs, scripts

- **Photos & videos** in private chats, with an optional **view once** mode (end-to-end encrypted, see docs/SECURITY.md for limits).
